<?php
// Inbox: 3-pane (list | conversation | patient info). ?id= opens a chat.
require_once __DIR__ . '/../lib/auth.php'; require __DIR__ . '/_layout.php'; require_once __DIR__ . '/../lib/lang.php';
$u = require_login();
$id = (int)($_GET['id'] ?? 0); $f = $_GET['f'] ?? 'all'; $s = trim($_GET['s'] ?? '');
$c = $id ? row("SELECT * FROM contacts WHERE id=?", [$id]) : null;

// ---- Actions ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $c) {
  csrf_check(); $a = $_POST['action'] ?? '';
  if ($a === 'send') {
    $t = trim($_POST['text'] ?? '');
    if ($t === '') flash('Message is empty', 'err');
    else {
      $r = node_call('POST', '/send', ['jid' => $c['jid'], 'text' => $t], 30);
      if ($r['code'] === 200 && !empty($r['data']['ok'])) {
        q("INSERT INTO messages(contact_id,direction,source,body,sent_by,status,wa_msg_id) VALUES(?,?,?,?,?,'sent',?)", [$id, 'out', 'staff', $t, $u['username'], $r['data']['id'] ?? null]);
        q("UPDATE contacts SET last_message_at=NOW(), last_out_at=NOW(), msg_out=msg_out+1, needs_human=0 WHERE id=?", [$id]);
      } else {
        q("INSERT INTO messages(contact_id,direction,source,body,sent_by,status,error) VALUES(?,?,?,?,?,'failed',?)", [$id, 'out', 'staff', $t, $u['username'], mb_substr($r['data']['error'] ?? $r['error'] ?: 'HTTP ' . $r['code'], 0, 255)]);
        flash('Send fail: ' . ($r['data']['error'] ?? $r['error'] ?: 'HTTP ' . $r['code']) . '. Is WhatsApp connected? (check the WhatsApp / QR page)', 'err');
      }
    }
  } elseif ($a === 'toggle_ai') { q("UPDATE contacts SET ai_enabled=1-ai_enabled, needs_human=IF(ai_enabled=0,0,needs_human) WHERE id=?", [$id]); log_activity($u['username'], "AI toggled for contact #$id"); }
  elseif ($a === 'resolve') { q("UPDATE contacts SET status=IF(status='open','resolved','open'), needs_human=0, unread=0 WHERE id=?", [$id]); }
  elseif ($a === 'save_info') { q("UPDATE contacts SET name=?, notes=?, tags=? WHERE id=?", [mb_substr(trim($_POST['name'] ?? ''), 0, 150), mb_substr($_POST['notes'] ?? '', 0, 5000), mb_substr(trim($_POST['tags'] ?? ''), 0, 255), $id]); flash('Patient info saved'); }
  elseif ($a === 'delete' && is_admin()) { q("DELETE FROM contacts WHERE id=?", [$id]); log_activity($u['username'], "Deleted chat #$id ({$c['phone']})", 'warn'); flash('Conversation deleted'); redirect('chats.php'); }
  redirect("chats.php?id=$id&f=" . urlencode($f));
}
if ($c) q("UPDATE contacts SET unread=0 WHERE id=?", [$id]);

// ---- List ----
$where = '1'; $p = [];
if ($f === 'unread') $where = 'c.unread>0'; elseif ($f === 'human') $where = 'c.needs_human=1 AND c.status="open"'; elseif ($f === 'open') $where = 'c.status="open"'; elseif ($f === 'resolved') $where = 'c.status="resolved"'; elseif ($f === 'aioff') $where = 'c.ai_enabled=0';
if ($s !== '') { $where .= ' AND (c.name LIKE ? OR c.phone LIKE ? OR c.notes LIKE ? OR EXISTS(SELECT 1 FROM messages m WHERE m.contact_id=c.id AND m.body LIKE ?))'; $p = array_fill(0, 4, "%$s%"); }
$list = all("SELECT c.*, (SELECT body FROM messages WHERE contact_id=c.id ORDER BY id DESC LIMIT 1) pv, (SELECT source FROM messages WHERE contact_id=c.id ORDER BY id DESC LIMIT 1) pvs FROM contacts c WHERE $where ORDER BY c.needs_human DESC, c.last_message_at DESC LIMIT 200", $p);
$counts = row("SELECT COUNT(*) a, SUM(unread>0) u, SUM(needs_human=1 AND status='open') h, SUM(status='open') o, SUM(status='resolved') r, SUM(ai_enabled=0) x FROM contacts") ?: [];
$msgs = $c ? array_reverse(all("SELECT * FROM messages WHERE contact_id=? ORDER BY id DESC LIMIT 400", [$id])) : [];
$cstat = $c ? row("SELECT COUNT(*) n, SUM(source='ai') ai, SUM(source='staff') st, SUM(tokens) tok, MIN(created_at) first FROM messages WHERE contact_id=?", [$id]) : null;
$quick = ['Hello! Welcome to 32 Teeth Hospital. How can we help you today?', 'Namaste! 32 Teeth Hospital me aapka swagat hai. Hum aapki kya madad kar sakte hain?', 'नमस्ते! 32 Teeth Hospital में आपका स्वागत है। हम आपकी क्या मदद कर सकते हैं?', 'When would you like to visit? We will confirm your appointment.', 'Aap kab aana chahenge? Hum appointment confirm kar denge.', 'Clinic address: 1st Floor, Prakash Medical, Daudnagar, Bihar - 824143', 'For urgent help please call: +91 87893 54445', 'The doctor will tell you the exact cost after the check-up.'];
$fl = flash();
layout_top('Inbox', $u, ['wide' => true]);
?>
<style>
/* Inbox v2: inline to avoid stale shared-CSS cache; only affects this page. */
.inbox {height:calc(100vh - 58px) !important; height:calc(100dvh - 58px) !important; grid-template-rows:minmax(0,1fr) !important; min-height:0 !important; overflow:hidden !important;}
.inbox .list, .inbox .conv, .inbox .info {min-height:0 !important; max-height:100% !important;}
.inbox .conv {height:100% !important; overflow:hidden !important;}
.inbox .msgs, .inbox .list .items {min-height:0 !important; overflow-y:auto !important; overscroll-behavior:contain;}
.inbox .msgs {flex:1 1 0 !important;}
.inbox .chd, .inbox .composer, .inbox .tools {flex-shrink:0 !important;}
.inbox .info {overflow-y:auto !important;}
.inbox .quick {flex-wrap:nowrap !important; overflow-x:auto !important;}
.inbox .quick button {flex:0 0 auto; white-space:nowrap;}
@media(max-width:860px) {.inbox .list,.inbox .conv {height:100% !important;}}
</style>
<div class="inbox <?= $c ? 'open' : '' ?>">
  <section class="list">
    <div class="tools">
      <form method="get" class="search"><?= icon('search') ?><input class="in" name="s" value="<?= e($s) ?>" placeholder="Search name, number or message…"><input type="hidden" name="f" value="<?= e($f) ?>"></form>
      <div class="chips" style="display:flex;overflow-x:auto"><?php foreach (['all' => 'All ' . (int)$counts['a'], 'unread' => 'Unread ' . (int)$counts['u'], 'human' => '✋ ' . (int)$counts['h'], 'open' => 'Open', 'resolved' => 'Done', 'aioff' => 'AI off'] as $k => $l): ?><a class="<?= $f === $k ? 'on' : '' ?>" href="?f=<?= $k ?>&s=<?= urlencode($s) ?>"><?= $l ?></a><?php endforeach; ?></div>
    </div>
    <div class="items">
    <?php if (!$list): ?><div class="empty"><div class="big">📭</div><?= $s ? 'Nothing found' : 'No conversations yet' ?></div><?php endif; ?>
    <?php foreach ($list as $r): ?>
      <a class="ci <?= $r['id'] === ($c['id'] ?? 0) ? 'on' : '' ?>" href="?id=<?= $r['id'] ?>&f=<?= e($f) ?>&s=<?= urlencode($s) ?>">
        <div class="av"><?= e(initials($r['name'], substr($r['phone'] ?? '', -2))) ?></div>
        <div class="t"><div class="n"><b><?= e($r['name'] ?: fmt_phone($r['phone'])) ?> <span class="mu xs" style="font-weight:400"><?= e(['hi' => 'HI', 'hing' => 'HING', 'en' => 'EN'][$r['lang']] ?? '') ?></span></b><small><?= e(ago($r['last_message_at'])) ?></small></div>
        <div class="pv"><?= $r['pvs'] && $r['pvs'] !== 'patient' ? '<span class="mu">↩ </span>' : '' ?><?= e(mb_substr($r['pv'] ?? '', 0, 70)) ?></div>
        <?php if ($r['needs_human'] || !$r['ai_enabled'] || $r['status'] === 'resolved' || $r['unread']): ?><div class="flags"><?php if ($r['unread']) echo '<span class="un">' . $r['unread'] . '</span>'; if ($r['needs_human']) echo '<span class="badge y">✋ staff</span>'; if (!$r['ai_enabled']) echo '<span class="badge n">AI off</span>'; if ($r['status'] === 'resolved') echo '<span class="badge g">done</span>'; ?></div><?php endif; ?></div>
      </a>
    <?php endforeach; ?>
    </div>
  </section>

  <section class="conv">
  <?php if (!$c): ?><div class="pholder"><div><div style="font-size:40px">💬</div><h3>Select a conversation</h3><p class="mu sm">Click a patient on the left. The full conversation will appear here and you can reply yourself.</p></div></div>
  <?php else: ?>
    <div class="chd"><a href="chats.php?f=<?= e($f) ?>" class="btn sm" style="display:none" id="backbtn">←</a><div class="av"><?= e(initials($c['name'], substr($c['phone'] ?? '', -2))) ?></div>
      <span class="badge n xs" title="Inbox scroll update installed">Scroll v2</span><div style="min-width:0"><b style="display:block;font-size:14px"><?= e($c['name'] ?: fmt_phone($c['phone'])) ?></b><small class="mu"><?= e(fmt_phone($c['phone'])) ?> · <span class="badge n xs" title="Language of the patient's last message">🌐 <?= e(lang_label((string)$c['lang'])) ?></span> · <?= $c['ai_enabled'] ? '<span class="ok">AI on</span>' : '<span class="warn">AI off · handled by staff</span>' ?></small></div><span class="sp"></span>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_ai"><button class="btn sm <?= $c['ai_enabled'] ? 'w' : 'p' ?>"><?= $c['ai_enabled'] ? icon('pause') . 'AI pause' : icon('play') . 'AI resume' ?></button></form>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="resolve"><button class="btn sm"><?= $c['status'] === 'open' ? icon('check') . 'Mark done' : icon('refresh') . 'Reopen' ?></button></form>
    </div>
    <?php if ($fl): ?><div class="flash <?= e($fl[1]) ?>" style="margin:10px 16px 0"><?= e($fl[0]) ?></div><?php endif; ?>
    <div class="msgs" id="msgs">
    <?php $day = ''; foreach ($msgs as $m): $d = date('Y-m-d', strtotime($m['created_at'])); if ($d !== $day) { $day = $d; echo '<div class="daysep">' . ($d === date('Y-m-d') ? 'Today' : ($d === date('Y-m-d', strtotime('-1 day')) ? 'Yesterday' : date('d M Y', strtotime($d)))) . '</div>'; } ?>
      <div class="m <?= $m['direction'] ?> <?= $m['source'] ?>"><?= e($m['body']) ?><div class="meta">
        <?php if ($m['direction'] === 'out'): ?><span class="badge <?= ['ai' => 'g', 'staff' => 'b', 'fallback' => 'y', 'system' => 'v'][$m['source']] ?? 'n' ?> xs" style="padding:0 6px"><?= $m['source'] === 'staff' ? '👤 ' . e($m['sent_by']) : ($m['source'] === 'ai' ? '🤖 AI' : ucfirst($m['source'])) ?></span><?php endif; ?>
        <?php if ($m['latency_ms']) echo '<span>' . round($m['latency_ms'] / 1000, 1) . 's</span>'; ?><span><?= date('h:i A', strtotime($m['created_at'])) ?></span>
        <?php if ($m['direction'] === 'out') echo $m['status'] === 'failed' ? '<span class="fail" title="' . e($m['error']) . '">✕ failed</span>' : ($m['status'] === 'sent' ? '<span class="tick">✓✓</span>' : '<span class="mu">✓</span>'); ?>
      </div></div>
    <?php endforeach; if (!$msgs) echo '<div class="daysep">No messages</div>'; ?>
    </div>
    <div class="composer">
      <div class="quick"><?php foreach ($quick as $qk) echo '<button type="button" onclick="ins(this.dataset.t)" data-t="' . e($qk) . '">' . e(mb_substr($qk, 0, 34)) . '…</button>'; ?></div>
      <form method="post" id="sf"><?= csrf_field() ?><input type="hidden" name="action" value="send"><textarea name="text" id="tx" placeholder="Type a reply as staff… (Enter = send, Shift+Enter = new line)" required></textarea><button class="btn p" style="height:44px"><?= icon('send') ?>Send</button></form>
      <div class="note"><span>This message is sent on behalf of <b>staff</b>.</span><?php if ($c['ai_enabled']): ?><span class="warn">Tip: click "AI pause" above if you want to handle this chat yourself, otherwise the AI will keep replying too.</span><?php endif; ?></div>
    </div>
  <?php endif; ?>
  </section>

  <aside class="info">
  <?php if ($c): ?>
    <div class="center"><div class="av lg" style="margin:0 auto 8px"><?= e(initials($c['name'], substr($c['phone'] ?? '', -2))) ?></div><b><?= e($c['name'] ?: 'Unknown') ?></b><div class="mono mu"><?= e(fmt_phone($c['phone'])) ?></div>
      <div class="row" style="justify-content:center;gap:6px;margin-top:8px"><a class="btn sm" href="https://wa.me/<?= e($c['phone']) ?>" target="_blank">WhatsApp</a><a class="btn sm" href="tel:+<?= e($c['phone']) ?>">Call</a></div></div>
    <div><h4>Conversation stats</h4>
      <div class="stat"><span class="mu">Total messages</span><b><?= (int)$cstat['n'] ?></b></div>
      <div class="stat"><span class="mu">Sent by patient</span><b><?= (int)$c['msg_in'] ?></b></div>
      <div class="stat"><span class="mu">AI replies</span><b><?= (int)$cstat['ai'] ?></b></div>
      <div class="stat"><span class="mu">Staff replies</span><b><?= (int)$cstat['st'] ?></b></div>
      <div class="stat"><span class="mu">Tokens used</span><b><?= number_format((int)$cstat['tok']) ?></b></div>
      <div class="stat"><span class="mu">First contact</span><b class="sm"><?= $cstat['first'] ? date('d M Y', strtotime($cstat['first'])) : '–' ?></b></div>
      <div class="stat"><span class="mu">Language</span><b><?= e(lang_label((string)$c['lang'])) ?></b></div>
      <div class="stat"><span class="mu">Status</span><span class="badge <?= $c['status'] === 'open' ? 'b' : 'g' ?>"><?= $c['status'] ?></span></div></div>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="save_info"><h4>Patient info</h4>
      <div class="fg"><label class="f">Name</label><input class="in" name="name" value="<?= e($c['name']) ?>"></div>
      <div class="fg"><label class="f">Tags <span class="mu">(comma separated)</span></label><input class="in" name="tags" value="<?= e($c['tags']) ?>" placeholder="implant, follow-up, vip"></div>
      <div class="fg"><label class="f">Staff notes <span class="mu">(the AI reads these too)</span></label><textarea class="in" name="notes" rows="4"><?= e($c['notes']) ?></textarea></div>
      <button class="btn blk">Save</button></form>
    <?php if (is_admin()): ?><form method="post" data-confirm="This will delete the whole conversation of this patient. Are you sure?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><button class="btn d blk"><?= icon('trash') ?>Delete conversation</button></form><?php endif; ?>
  <?php else: ?><div class="pholder mu sm">Patient details will appear here</div><?php endif; ?>
  </aside>
</div>
<script>
// Fit the inbox to the visible viewport, including pages with CSS zoom.
function fitInboxViewport(){
  const box=document.querySelector('.inbox'); if(!box) return;
  const rect=box.getBoundingClientRect(), cssHeight=parseFloat(getComputedStyle(box).height);
  const scale=cssHeight>0 ? rect.height/cssHeight : 1;
  const viewportHeight=window.visualViewport ? window.visualViewport.height : window.innerHeight;
  const height=(viewportHeight-rect.top)/(scale || 1);
  if(height>100 && Number.isFinite(height)) box.style.setProperty('height',height+'px','important');
}
fitInboxViewport();
window.addEventListener('resize',fitInboxViewport);
if(window.visualViewport) window.visualViewport.addEventListener('resize',fitInboxViewport);
const b=document.getElementById('msgs');
const inboxScrollKey='inbox-scroll:'+location.pathname+location.search;
try {
  const saved=JSON.parse(sessionStorage.getItem(inboxScrollKey)||'null');
  if(b) b.scrollTop=saved && !saved.atBottom ? saved.messages : b.scrollHeight;
  const list=document.querySelector('.inbox .items'), info=document.querySelector('.inbox .info');
  if(saved && list) list.scrollTop=saved.list||0;
  if(saved && info) info.scrollTop=saved.info||0;
  sessionStorage.removeItem(inboxScrollKey);
} catch(e) { if(b)b.scrollTop=b.scrollHeight; }
function saveInboxScroll(){
  try {
    const list=document.querySelector('.inbox .items'), info=document.querySelector('.inbox .info');
    sessionStorage.setItem(inboxScrollKey,JSON.stringify({
      messages:b?b.scrollTop:0, atBottom:!b || b.scrollHeight-b.clientHeight-b.scrollTop<60,
      list:list?list.scrollTop:0, info:info?info.scrollTop:0
    }));
  } catch(e) {}
}
let inboxEditing=false;
document.querySelectorAll('.inbox form').forEach(form=>form.addEventListener('input',()=>{inboxEditing=true}));
const tx=document.getElementById('tx');function ins(t){tx.value=t;tx.focus()}
if(tx){tx.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();if(tx.value.trim())document.getElementById('sf').submit()}});tx.addEventListener('input',()=>{tx.style.height='44px';tx.style.height=Math.min(140,tx.scrollHeight)+'px'})}
if(matchMedia('(max-width:860px)').matches){const bb=document.getElementById('backbtn');if(bb)bb.style.display='inline-flex'}
// Auto-refresh only when not editing or reading older messages.
setInterval(()=>{
  const el=document.activeElement;
  const focused=el && el.matches('input,textarea,select');
  const reading=b && b.scrollHeight-b.clientHeight-b.scrollTop>=60;
  if(!inboxEditing && !focused && !reading && !String(window.getSelection())){
    saveInboxScroll(); location.reload();
  }
},25000);
</script>
<?php layout_bottom();
