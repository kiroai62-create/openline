// =====================================================================
//  32 Teeth Hospital - WhatsApp Gateway (Node + Baileys) for Hugging Face Space
//  Sirf WhatsApp connection ka kaam. Saara logic + DB Hostinger (PHP) par hai.
// =====================================================================
import express from 'express';
import pino from 'pino';
import QRCode from 'qrcode';
import makeWASocket, { DisconnectReason, initAuthCreds, BufferJSON, proto, fetchLatestBaileysVersion, Browsers } from '@whiskeysockets/baileys';

const PORT = process.env.SERVER_PORT || process.env.PORT || 7860;
const PHP_URL = (process.env.PHP_URL || '').replace(/\/+$/, '');
const API_SECRET = process.env.API_SECRET || '';
const SELF_URL = (process.env.SPACE_HOST ? 'https://' + process.env.SPACE_HOST : (process.env.SELF_URL || '')).replace(/\/+$/, '');
const logger = pino({ level: process.env.LOG_LEVEL || 'silent' });
const VERSION = '2.0.0';

if (!PHP_URL || !API_SECRET) console.error('⚠️  PHP_URL / API_SECRET secrets set nahi hain! (Space Settings -> Variables and secrets)');

// ---------- State ----------
let sock = null, qrDataUrl = null, qrRaw = null, connected = false, me = null, lastError = null, reconnectTimer = null;
const startedAt = Date.now();
const stats = { received: 0, replied: 0, failed: 0, ignored: 0, reconnects: 0, lastMessageAt: null, lastReplyAt: null };
let store = { creds: null, keys: {} };
let saveTimer = null, saving = false, dirty = false;
let cfg = { fallback_message: 'Dhanyavaad! Abhi system busy hai. Kripya call karein: +91 87893 54445', reply_delay_min: 5000, reply_delay_max: 8000, typing_indicator: true, mark_read: true, ignore_groups: true };
const queues = new Map(); // per-chat sequential processing

// ---------- PHP helpers ----------
async function php(path, opts = {}) {
  const r = await fetch(PHP_URL + path, {
    method: opts.method || 'GET',
    headers: { 'X-API-KEY': API_SECRET, 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    signal: AbortSignal.timeout(opts.timeout || 50000),
  });
  const txt = await r.text();
  let j = null; try { j = JSON.parse(txt); } catch { }
  if (!r.ok) throw new Error('PHP ' + r.status + ' ' + (j?.error || txt.slice(0, 120)));
  return j || {};
}
const event = (type, detail = '') => php('/api/event.php', { method: 'POST', body: { type, detail: String(detail).slice(0, 500), state: snapshot() }, timeout: 15000 }).catch(() => { });
const snapshot = () => ({ connected, me: me ? { id: me.id, name: me.name } : null, uptime: Math.floor((Date.now() - startedAt) / 1000), stats, version: VERSION, needsQr: !!qrDataUrl });

async function refreshConfig() {
  try { const j = await php('/api/config.php', { timeout: 15000 }); cfg = { ...cfg, ...j }; console.log(`Reply delay config loaded: min=${cfg.reply_delay_min}ms max=${cfg.reply_delay_max}ms`); } catch (e) { console.warn('config fetch fail:', e.message); }
}

// ---------- Session (Hostinger DB me) ----------
async function loadSession() {
  try {
    const j = await php('/api/session.php');
    if (j.data) { store = JSON.parse(j.data, BufferJSON.reviver); console.log('✅ Session DB se load hua (' + j.updated_at + ')'); }
    else console.log('ℹ️  Naya session: dashboard me QR scan karo');
  } catch (e) { console.error('Session load fail:', e.message); }
  if (!store?.creds) store = { creds: initAuthCreds(), keys: {} };
  if (!store.keys) store.keys = {};
}
function saveSession(now = false) {
  dirty = true; clearTimeout(saveTimer);
  const run = async () => {
    if (saving) { saveTimer = setTimeout(run, 1500); return; }
    saving = true; dirty = false;
    try { await php('/api/session.php', { method: 'POST', body: { data: JSON.stringify(store, BufferJSON.replacer) } }); }
    catch (e) { console.error('Session save fail:', e.message); dirty = true; }
    saving = false;
    if (dirty) saveTimer = setTimeout(run, 3000);
  };
  now ? run() : (saveTimer = setTimeout(run, 2500));
}
async function clearSession() {
  try { await php('/api/session.php', { method: 'DELETE' }); } catch { }
  store = { creds: initAuthCreds(), keys: {} };
}
function authState() {
  return {
    creds: store.creds,
    keys: {
      get: (type, ids) => {
        const out = {};
        for (const id of ids) {
          let v = store.keys[type]?.[id];
          if (v && type === 'app-state-sync-key') v = proto.Message.AppStateSyncKeyData.fromObject(v);
          if (v) out[id] = v;
        }
        return out;
      },
      set: (data) => {
        for (const t in data) {
          store.keys[t] = store.keys[t] || {};
          for (const id in data[t]) { const v = data[t][id]; if (v) store.keys[t][id] = v; else delete store.keys[t][id]; }
        }
        saveSession();
      },
    },
  };
}

// ---------- WhatsApp ----------
function textOf(m) {
  const x = m.message || {};
  const inner = x.ephemeralMessage?.message || x.viewOnceMessage?.message || x.viewOnceMessageV2?.message || x;
  return inner.conversation || inner.extendedTextMessage?.text || inner.imageMessage?.caption || inner.videoMessage?.caption ||
    inner.documentMessage?.caption || inner.buttonsResponseMessage?.selectedDisplayText || inner.listResponseMessage?.title ||
    inner.templateButtonReplyMessage?.selectedDisplayText || null;
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function handleMessage(m) {
  const jid = m.key.remoteJid;
  if (!jid || m.key.fromMe) return;
  if (jid === 'status@broadcast' || jid.endsWith('@newsletter') || jid.endsWith('@broadcast')) { stats.ignored++; return; }
  if (cfg.ignore_groups && jid.endsWith('@g.us')) { stats.ignored++; return; }
  let text = textOf(m);
  if (!text) {
    const x = m.message || {};
    if (x.audioMessage) text = '[Voice message bheja]'; else if (x.imageMessage) text = '[Photo bheji]'; else if (x.documentMessage) text = '[Document bheja]'; else if (x.locationMessage) text = '[Location bheji]'; else { stats.ignored++; return; }
  }
  stats.received++; stats.lastMessageAt = new Date().toISOString();
  if (cfg.mark_read) await sock.readMessages([m.key]).catch(() => { });

  let reply = null, dbId = null, source = null;
  try {
    const j = await php('/api/incoming.php', { method: 'POST', body: { jid, name: m.pushName || '', text, msg_id: m.key.id, ts: Number(m.messageTimestamp) || Math.floor(Date.now() / 1000) } });
    reply = j.reply || null; dbId = j.msg_db_id || null; source = j.source || null;
    if (!reply) return; // AI off / duplicate / handoff without text
  } catch (e) {
    console.error('PHP error:', e.message); reply = cfg.fallback_message; source = 'fallback';
  }

  if (cfg.typing_indicator) await sock.sendPresenceUpdate('composing', jid).catch(() => { });
  const min = Number(cfg.reply_delay_min) || 0, max = Math.max(min, Number(cfg.reply_delay_max) || min);
  const delayMs = Math.round(min + Math.random() * (max - min));
  console.log(`Reply delay before send: ${delayMs}ms`);
  await sleep(delayMs);
  if (cfg.typing_indicator) await sock.sendPresenceUpdate('paused', jid).catch(() => { });
  try {
    const r = await sock.sendMessage(jid, { text: reply });
    stats.replied++; stats.lastReplyAt = new Date().toISOString();
    if (dbId) php('/api/delivered.php', { method: 'POST', body: { msg_db_id: dbId, ok: true, wa_id: r?.key?.id }, timeout: 15000 }).catch(() => { });
  } catch (e) {
    stats.failed++; console.error('Send fail:', e.message);
    if (dbId) php('/api/delivered.php', { method: 'POST', body: { msg_db_id: dbId, ok: false, error: e.message }, timeout: 15000 }).catch(() => { });
  }
}
function enqueue(jid, fn) {
  const prev = queues.get(jid) || Promise.resolve();
  const next = prev.then(fn).catch(e => console.error('queue err', e.message)).finally(() => { if (queues.get(jid) === next) queues.delete(jid); });
  queues.set(jid, next);
}

async function start() {
  clearTimeout(reconnectTimer);
  let version; try { ({ version } = await fetchLatestBaileysVersion()); } catch { }
  sock = makeWASocket({
    version, auth: authState(), logger, printQRInTerminal: false,
    browser: Browsers.ubuntu('Chrome'), markOnlineOnConnect: false, syncFullHistory: false,
    generateHighQualityLinkPreview: false, connectTimeoutMs: 60000, keepAliveIntervalMs: 20000,
  });

  sock.ev.on('creds.update', (u) => { Object.assign(store.creds, u); saveSession(); });

  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
    if (qr) { qrRaw = qr; qrDataUrl = await QRCode.toDataURL(qr, { margin: 1, width: 320 }); connected = false; console.log('📱 QR ready: dashboard -> WhatsApp page me scan karo'); event('qr'); }
    if (connection === 'open') {
      connected = true; qrDataUrl = null; qrRaw = null; me = sock.user; lastError = null;
      saveSession(true); console.log('✅ WhatsApp connected:', me?.id); event('connected', me?.id || '');
    }
    if (connection === 'close') {
      connected = false;
      const code = lastDisconnect?.error?.output?.statusCode;
      lastError = (lastDisconnect?.error?.message || '') + (code ? ' (' + code + ')' : '');
      console.log('❌ Connection closed:', lastError);
      event('disconnected', lastError);
      if (code === DisconnectReason.loggedOut || code === 401 || code === 403) { console.log('Logged out -> session clear, naya QR banega'); await clearSession(); }
      stats.reconnects++;
      reconnectTimer = setTimeout(start, code === DisconnectReason.restartRequired ? 1000 : 5000);
    }
  });

  sock.ev.on('messages.upsert', ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) enqueue(m.key?.remoteJid || 'x', () => handleMessage(m));
  });
}

// ---------- HTTP API ----------
const app = express();
app.use(express.json({ limit: '1mb' }));
app.disable('x-powered-by');
const auth = (req, res, next) => (API_SECRET && req.get('X-API-KEY') === API_SECRET) ? next() : res.status(401).json({ error: 'unauthorized' });

app.get('/', (_, res) => res.type('html').send(`<!doctype html><meta charset=utf-8><body style="font-family:system-ui;background:#0b1410;color:#d1fae5;display:grid;place-items:center;height:100vh;margin:0"><div style="text-align:center"><div style="font-size:40px">🦷</div><h2 style="margin:8px 0">32 Teeth WhatsApp Gateway</h2><p>Status: <b style="color:${connected ? '#4ade80' : '#fbbf24'}">${connected ? 'WhatsApp connected' : (qrDataUrl ? 'QR scan pending' : 'connecting…')}</b></p><p style="opacity:.6;font-size:13px">v${VERSION} · uptime ${Math.floor((Date.now() - startedAt) / 60)}s · manage from Hostinger dashboard</p></div>`));
app.get('/health', (_, res) => res.json({ ok: true, connected, needsQr: !!qrDataUrl, uptime: Math.floor((Date.now() - startedAt) / 1000), version: VERSION, stats }));
app.get('/status', auth, (_, res) => res.json({ ok: true, ...snapshot(), qr: qrDataUrl, lastError, phpConfigured: !!PHP_URL }));
app.post('/send', auth, async (req, res) => {
  let { jid, text } = req.body || {};
  if (!jid || !text) return res.status(400).json({ error: 'jid & text required' });
  if (!jid.includes('@')) jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (!connected || !sock) return res.status(503).json({ error: 'WhatsApp connected nahi hai' });
  try {
    if (cfg.typing_indicator) { await sock.sendPresenceUpdate('composing', jid).catch(() => { }); await sleep(600); }
    const r = await sock.sendMessage(jid, { text: String(text) });
    stats.replied++; res.json({ ok: true, id: r?.key?.id });
  } catch (e) { stats.failed++; res.status(500).json({ error: e.message }); }
});
app.post('/reload-config', auth, async (_, res) => { await refreshConfig(); res.json({ ok: true, cfg }); });
app.post('/logout', auth, async (_, res) => {
  try { await sock?.logout(); } catch { }
  await clearSession(); connected = false; me = null; res.json({ ok: true });
  event('logout'); setTimeout(start, 1500);
});
app.post('/restart', auth, (_, res) => { res.json({ ok: true }); event('restart'); try { sock?.end(new Error('manual restart')); } catch { } });

app.listen(PORT, '0.0.0.0', async () => {
  console.log(`🚀 Gateway v${VERSION} on port ${PORT}`);
  await refreshConfig();
  await loadSession();
  start();
  event('boot', 'Space started');
  setInterval(refreshConfig, 5 * 60 * 1000);            // settings refresh
  setInterval(() => event('heartbeat'), 10 * 60 * 1000); // PHP ko batate raho ki zinda hain
  // Self-ping backup (Hostinger cron ke alawa): HF Space ko khud bhi jagaye rakhta hai
  if (SELF_URL) setInterval(() => fetch(SELF_URL + '/health').catch(() => { }), 10 * 60 * 1000);
});
process.on('unhandledRejection', e => console.error('unhandledRejection:', e?.message || e));
process.on('uncaughtException', e => console.error('uncaughtException:', e?.message || e));
